let response;
let differences = [];
let nDifferencesFound = 0;

const BASE_URL = "HTTP://localhost:5124/api/TrovaDifferenze/Random";


this.onload = function() {
    fetch(BASE_URL)
    .then(x => x.json())
    .then(o => {
        response = o;
        let btnStart = document.querySelector("#btnStart"); 
        btnStart.disabled = false;
        
        let immagineOriginale = document.querySelector("#immagineOriginale");
        let immagineModificata = document.querySelector("#immagineModificata")

        immagineOriginale.src = response["percorsoOriginale"];
        immagineModificata.src = response["percorsoModificata"];

        btnStart.onclick = () => {
            btnStart.disabled = true;
            immagineModificata.style.display = "none";
            document.body.onresize = (event) => { on_resize(event); }
            immagineOriginale.id = "workImage";

            const dataWidth = response["width"];
            const realWidth = document.querySelector("#workImage").clientWidth;
            
            const FACTOR = dataWidth / realWidth;
            
            let container = document.querySelector(".image-container");
            for(let i = 0; i < response["elencoDifferenze"].length; i++) {
                let differenza = response["elencoDifferenze"][i];
                let circle = NewCircle(differenza["x"] / FACTOR, differenza["y"] / FACTOR, differenza["raggio"] / FACTOR);

                differences.push({
                    "differenza": differenza,
                    "circleDiv": circle,
                    "clicked": false
                });

                circle.onclick = () => { on_click(circle); };

                container.appendChild(circle);
            }

            UpdateSpanOutput();
        }

    }).catch(()=>{
        new Alert("warning", "Errore nel caricamento delle immagini!", true, document.body);
    })
}


let on_click = (circle) => {
    let differenza = differences.find(x => x["circleDiv"] == circle);
    if(differenza["clicked"]) return;
    circle.classList.add("circleDifferenzaClicked");
    nDifferencesFound++;
    UpdateSpanOutput();
    differenza["clicked"] = true;

}


let on_resize = (e) => {
    const dataWidth = response["width"];
    const realWidth = document.querySelector("#workImage").clientWidth;
    const FACTOR = dataWidth / realWidth;

    differences.forEach(d => {
        ResizeAndMoveCircle(d["circleDiv"], d["differenza"]["x"] / FACTOR, d["differenza"]["y"] / FACTOR, d["differenza"]["raggio"] / FACTOR);
    })
}

function UpdateSpanOutput() {
    document.querySelector("#spanOutput").innerText = "Trovate " + nDifferencesFound + " differenze su " + response["elencoDifferenze"].length;

    if(nDifferencesFound == response["elencoDifferenze"].length) {
        let alert = new Alert("success", "Complimenti, hai trovato tutte le differenze!", true, document.body)
        alert.onclick = () => {
            window.location.href = window.location.href;
        }
    };
}

function NewCircle(x, y, raggio) {
    let div = document.createElement("div");
    div.classList.add("circleDifferenza");
    ResizeAndMoveCircle(div, x, y, raggio);
    return div;
}

function ResizeAndMoveCircle(circle, newX, newY, newRaggio) {
    x = Math.floor(newX);
    y = Math.floor(newY);
    raggio = Math.floor(newRaggio);

    circle.style.width = (raggio * 2) + "px";
    circle.style.height = (raggio * 2) + "px";
    circle.style.top = "-"+ raggio + "px";
    circle.style.left = "-" + raggio + "px";

    let translateString = "translate("+ x + "px, " + y + "px)";
    circle.style.WebkitTransform = translateString; 
    circle.style.msTransform = translateString;
    circle.style.transform = translateString
}
function NumDifferenze()
{
    document.getElementById(id).style.display = ''; // show
   
    
  
}