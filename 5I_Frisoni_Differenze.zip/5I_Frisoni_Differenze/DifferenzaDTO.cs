public class DifferenzaDTO {
    public int X { get; set; }
    public int Y {get; set; }
    public int Raggio {get; set; }   
}